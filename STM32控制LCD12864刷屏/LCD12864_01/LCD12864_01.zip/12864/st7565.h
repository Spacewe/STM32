#ifndef __ST7565_H
#define __ST7565_H

#include <stdio.h>
#include "charcode.h"
#include "stm32f1xx_hal.h"

////---�����ֿ�ͷ�ļ�
#define CHAR_CODE


//---�ض���ؼ���---//
#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint 
#define uint unsigned int
#endif

//--��ʱʹ�õ�IO��--//
//#define DATA_PORT P0
//sbit LCD12864_CS   = P3^1;
//sbit LCD12864_RSET = P3^2;
//sbit LCD12864_RS   = P3^5;
//sbit LCD12864_RW   = P3^7;
//sbit LCD12864_RD   = P3^6;

//--����ȫ�ֺ���--//
void LcdSt7565_WriteCmd(uint16_t cmd);
void LcdSt7565_WriteData(uint16_t dat);
void Lcd12864_Init();
void Lcd12864_ClearScreen(void);
uchar Lcd12864_Write16CnCHAR(uchar x, uchar y, uchar *cn);

#endif
