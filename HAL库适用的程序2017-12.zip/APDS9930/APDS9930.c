#include "math.h"
#include "APDS9930.h"
#include "stm32f1xx_hal.h"
#include "i2c.h"
uint16_t  CH0_data, CH1_data, Prox_data;

void APDS9930_Write_Register( uint8_t Register_Address, uint8_t Configuration_Byte)
{ 
  
    Register_Address |=  0x80 ;
  
    HAL_I2C_Mem_Write(&hi2c1, 0x72, Register_Address, 1, &Configuration_Byte, 1, 0x10);
  
}


uint16_t APDS9930_Read_Register(uint8_t Register_Address)
{  
    uint8_t pData[2] = {0};
    uint16_t tmp;
    
    Register_Address |=  0xA0 ;
  
    HAL_I2C_Master_Transmit(&hi2c1, 0x72, &Register_Address, 1, 0x10);
    HAL_I2C_Master_Receive(&hi2c1, 0x72, pData, 2, 0x10);
  
    tmp = pData[1] * 256 + pData[0];
  
    return tmp ; 
   
}

void APDS9930_Init(void)
{ 
  uint8_t PDRIVE, PDIODE, PGAIN, AGAIN;  
  uint8_t WEN, PEN, AEN, PON; 
  
  APDS9930_Write_Register(0x00, 0x00); //Disable and Powerdown
  APDS9930_Write_Register(0x01, 0x00); // ALS_TIME 
  APDS9930_Write_Register(0x02, 0x00); // PROX_TIME
  APDS9930_Write_Register(0x03, 0x00); // WAIT_TIME
  APDS9930_Write_Register(0x0E, 0X01); // PPULSE = 0x01 Minimum Prox Pulse Count

  PDRIVE = 0X00; //100mA of LED Power
  PDIODE = 0x20; //CH1 Diode
  PGAIN = 0X00;  //1x Prox gain
  AGAIN = 0X00;  //1x ALS gain
  APDS9930_Write_Register(0x0F, PDRIVE | PDIODE | PGAIN | AGAIN);

  WEN = 0x08; // Enable Wait
  PEN = 0x04; // Enable Prox
  AEN = 0x02; // Enable ALS
  PON = 0x01; // Enable Power On
  APDS9930_Write_Register(0X00, WEN | PEN | AEN | PON); // WriteRegData(0,0x0f);
	HAL_Delay(12);
  //Delay_ms(12); //Wait for 12 ms

}
  
void APDS9930_Read_Data(void)
{
          
//  uint16_t CH0_data, CH1_data, Prox_data;  
  
  CH0_data = APDS9930_Read_Register(0x14);
  CH1_data = APDS9930_Read_Register(0x16);
  Prox_data = APDS9930_Read_Register(0x18);
	//printf("%d\n",CH0_data);
	//printf("%d\n",CH1_data);
	printf("%d\n",Prox_data);
	//printf("%d \n%d\n%d \n\n",CH0_data,CH1_data,Prox_data);
}