#ifndef __APDS9930_H
#define	__APDS9930_H
#include "stm32f1xx_hal.h"
void APDS9930_Write_Register(uint8_t Register_Address, uint8_t Configuration_Byte);
uint16_t APDS9930_Read_Register(uint8_t Register_Address);
void APDS9930_Init(void);
void APDS9930_Read_Data(void);
#endif
