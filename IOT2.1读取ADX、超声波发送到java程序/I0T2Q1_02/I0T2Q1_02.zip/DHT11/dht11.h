#ifndef __DHT11_H
#define __DHT11_H

#include<stdio.h>
#include "stm32f1xx_hal.h"

void DHT11_Input(void);
void DHT11_Onput(void);


void DHT11_Start(void);

uint16_t DHT11_ReadByte(void);
uint16_t DHT11_ReadData(void);
uint16_t DHT11_GetTemp(void);
uint16_t DHT11_GetHem(void);



//void delay_us(uint32_t i);
//void delay_ms(uint32_t i);

#endif
