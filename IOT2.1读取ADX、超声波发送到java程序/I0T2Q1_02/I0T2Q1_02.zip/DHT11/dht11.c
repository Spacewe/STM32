#include "dht11.h"
#include "delay.h" 

uint16_t DHT11_hem_high,DHT11_hem_low,DHT11_temp_high,DHT11_temp_low;
/*******************************************************************************
����Ϊ����ģʽ
*******************************************************************************/
void DHT11_Input(void)
{
		GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
	
	  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
	
//	GPIO_InitStruct.Pin = GPIO_PIN_0;
//  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}
/*******************************************************************************
����Ϊ���ģʽ
*******************************************************************************/
void DHT11_Onput(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
	
	
	GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}
 
  
void DHT11_Start(void)
{  
  //delay_init(); 
  DHT11_Onput();  
  DHT11_hem_high   = 0;  
  DHT11_hem_low    = 0;  
  DHT11_temp_high  = 0;  
  DHT11_temp_low   = 0;  
}  
  
uint16_t DHT11_ReadByte(void) 
{  
  uint8_t temp=0,i,cout; 
  DHT11_Input();  
  for(i=0;i<8;i++) 
  {  
    cout=1;
    while(!HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0) && cout++); 
    delay_us(30);
    temp = temp << 1;  
//		printf("********************\n");
//		printf("[temp x]: %x\n",temp);
//		printf("[temp d]: %d\n",temp);
//		printf("[temp o]: %o\n",temp);
//		printf("********************\n");
    if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0)  == GPIO_PIN_SET)
    {  
      temp |=1; 
    }  
      
    cout=1;  
    while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0)  && cout++);  
  }  
  return temp; 
}  
  
uint16_t DHT11_ReadData(void) 
{  
  uint16_t cout = 1; 
  uint16_t temp_high,temp_low,hem_high,hem_low,Check;
    
  DHT11_Onput(); 
    
  //DHT11_ResetBit(); 
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
  delay_ms(20);
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
  delay_us(30);  
    
  DHT11_Input();  
    
  
  if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0) == GPIO_PIN_RESET)  
  {  
    cout = 1;
    while(!HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0)&& cout++);  
      
    cout = 1; 
    while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0) && cout++);  
    
  
      
    hem_high = DHT11_ReadByte(); 
    hem_low  = DHT11_ReadByte();  
    temp_high  = DHT11_ReadByte(); 
    temp_low   = DHT11_ReadByte();  
    Check = DHT11_ReadByte();  
       
    if(Check == ( temp_high + temp_low + hem_high + hem_low ))  
    {  
      DHT11_hem_high = hem_high;  
      DHT11_hem_low = hem_low; 
      DHT11_temp_high = temp_high; 
      DHT11_temp_low  = temp_low; 
        
      return 1; 
    }  
    else  
    {  
      return 0;
    }  
  }  
  return 0;  
}  
  
uint16_t DHT11_GetTemp(void)  
{  

    
  return(DHT11_temp_high <<8 | DHT11_temp_low);  
}  
  
uint16_t DHT11_GetHem(void) 
{  
  return(DHT11_hem_high <<8 | DHT11_hem_low);  
} 
//void delay_us(uint32_t i)
//{
//	uint32_t temp;
//	SysTick->LOAD=9*i;		 //������װ��ֵ, 72MHZʱ
//	SysTick->CTRL=0X01;		 //ʹ�ܣ����������޶����������ⲿʱ��Դ
//	SysTick->VAL=0;		   	 //���������
//	do
//	{
//		temp=SysTick->CTRL;		   //��ȡ��ǰ������ֵ
//	}
//	while((temp&0x01)&&(!(temp&(1<<16))));	 //�ȴ�ʱ�䵽��
//	SysTick->CTRL=0;	//�رռ�����
//	SysTick->VAL=0;		//��ռ�����
//}
//void delay_ms(uint32_t i)
//{
//	uint32_t temp;
//	SysTick->LOAD=9000*i;		 //������װ��ֵ, 72MHZʱ
//	SysTick->CTRL=0X01;		 //ʹ�ܣ����������޶����������ⲿʱ��Դ
//	SysTick->VAL=0;		   	 //���������
//	do
//	{
//		temp=SysTick->CTRL;		   //��ȡ��ǰ������ֵ
//	}
//	while((temp&0x01)&&(!(temp&(1<<16))));	 //�ȴ�ʱ�䵽��
//	SysTick->CTRL=0;	//�رռ�����
//	SysTick->VAL=0;		//��ռ�����
//}
