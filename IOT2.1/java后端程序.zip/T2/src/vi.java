import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardXYItemLabelGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.TextAnchor;


public class vi {
	JLabel ultrasonic;
	JLabel ultrasonic_num;
	JLabel temperature;
	JLabel temperature_num;
	JLabel humidity;
	JLabel humidity_num;
	JLabel heartrate;
	JLabel heartrate_num;
	JLabel oxygen;
	JLabel oxygen_num;
	JLabel flame;
	JLabel flame_state;
	JLabel photosensitive;
	JLabel photosensitive_state;
	JLabel thermalinfrared;
	JLabel thermalinfrared_state;
	JLabel ADX;
	
	JButton opensever;
	JButton closesever;
	JButton flash;
	JFrame frame ;
	JPanel panellabel;
	JPanel paneladx;
	JPanel paneltext;
	ChartPanel paneladxl;
	JFreeChart chart;
	
	JTextArea textArea;
	
	ServerSocket serverSocket;
	PrintWriter writer;
	Socket socket;
	BufferedReader reader;
	InputStreamReader streamReader;
	
	DefaultCategoryDataset adx345;
	Queue<Integer> AdxlX = new LinkedList<Integer>();
	Queue<Integer> AdxlY = new LinkedList<Integer>();
	Queue<Integer> AdxlZ = new LinkedList<Integer>();
	Queue<Integer> AdxlV = new LinkedList<Integer>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		vi v = new vi();
		v.go();
	}
	public void go() {
		frame = new JFrame("IOT2.1");
		paneladx = new JPanel();
		panellabel = new JPanel();
		paneltext = new JPanel();
		
		ultrasonic = new JLabel("������ :");
		ultrasonic.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		ultrasonic_num = new JLabel("0");
		ultrasonic_num.setFont(new Font("Helvetica", Font.PLAIN, 18));
		temperature = new JLabel("�¶� :");
		temperature.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		temperature_num = new JLabel("0");
		temperature_num.setFont(new Font("Helvetica", Font.PLAIN, 18));
		humidity = new JLabel("ʪ�� :");
		humidity.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		humidity_num = new JLabel("0");
		humidity_num.setFont(new Font("Helvetica", Font.PLAIN, 18));
		heartrate = new JLabel("���� :");
		heartrate.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		heartrate_num = new JLabel("0");
		heartrate_num.setFont(new Font("Helvetica", Font.PLAIN, 18));
		oxygen = new JLabel("Ѫ�� :");
		oxygen.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		oxygen_num = new JLabel("0");
		oxygen_num.setFont(new Font("Helvetica", Font.PLAIN, 18));
		flame = new JLabel("���� :");
		flame.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		flame_state = new JLabel("����");
		flame_state.setFont(new Font("Helvetica", Font.PLAIN, 18));
		flash = new JButton("ˢ��");
		flash.addActionListener(new Flash());
		
		photosensitive = new JLabel("���� :");
		photosensitive.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		photosensitive_state = new JLabel("����");
		photosensitive_state.setFont(new Font("Helvetica", Font.PLAIN, 18));
		thermalinfrared = new JLabel("�Ⱥ��� :");
		thermalinfrared.setFont(new Font("Dialog", Font.PLAIN, 20));
		thermalinfrared_state = new JLabel("����");
		thermalinfrared_state.setFont(new Font("Helvetica", Font.PLAIN, 18));
		ADX = new JLabel("ADX");
		opensever = new JButton("Open Sever");
		closesever = new JButton("Close Sever");
		opensever.addActionListener(new SeverOpen());
		closesever.addActionListener(new SeverClose());
		
		textArea = new JTextArea(20,20);
		textArea.setLineWrap(true); //����ʹ�ù�����
		
		//���г�ʼ��
		for(int i =0;i<10;i++)
		{
			AdxlX.add(0);
			AdxlY.offer(0);
			AdxlZ.offer(0);
			AdxlV.offer(0);
		}
		
		//���ù�����
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		paneltext.setLayout(new BoxLayout(paneltext, BoxLayout.Y_AXIS));
		paneltext.add(scrollPane);
		
		panellabel.setLayout(new GridLayout(9,2));
		panellabel.setBackground(Color.cyan);
		panellabel.add(opensever);
		panellabel.add(closesever);
		panellabel.add(ultrasonic);
		panellabel.add(ultrasonic_num);
		panellabel.add(temperature);
		panellabel.add(temperature_num);
		panellabel.add(humidity);
		panellabel.add(humidity_num);
		panellabel.add(heartrate);
		panellabel.add(heartrate_num);
		panellabel.add(oxygen);
		panellabel.add(oxygen_num);
		panellabel.add(flame);
		panellabel.add(flame_state);
		panellabel.add(photosensitive);
		panellabel.add(photosensitive_state);
		panellabel.add(thermalinfrared);
		panellabel.add(thermalinfrared_state);
		
		adx345 = new DefaultCategoryDataset();
		adx345.addValue(20, "X", "1");
		adx345.addValue(32, "X", "2");
		adx345.addValue(52, "X", "3");
		adx345.addValue(62, "X", "4");
		adx345.addValue(2, "X", "5");
		adx345.addValue(21, "X", "6");
		adx345.addValue(12, "X", "7");
		adx345.addValue(222, "X", "8");
		adx345.addValue(23, "X", "9");
		adx345.addValue(24, "X", "10");
	
		adx345.addValue(56, "Y", "1");
		adx345.addValue(22, "Y", "2");
		adx345.addValue(32, "Y", "3");
		adx345.addValue(92, "Y", "4");
		adx345.addValue(12, "Y", "5");
		adx345.addValue(41, "Y", "6");
		adx345.addValue(15, "Y", "7");
		adx345.addValue(62, "Y", "8");
		adx345.addValue(27, "Y", "9");
		adx345.addValue(5, "Y", "10");
		
		adx345.addValue(16, "Z", "1");
		adx345.addValue(22, "Z", "2");
		adx345.addValue(22, "Z", "3");
		adx345.addValue(2, "Z", "4");
		adx345.addValue(12, "Z", "5");
		adx345.addValue(31, "Z", "6");
		adx345.addValue(15, "Z", "7");
		adx345.addValue(22, "Z", "8");
		adx345.addValue(57, "Z", "9");
		adx345.addValue(69, "Z", "10");
        
		adx345.addValue(0, "V", "1");
		adx345.addValue(0, "V", "2");
		adx345.addValue(0, "V", "3");
		adx345.addValue(27, "V", "4");
		adx345.addValue(0, "V", "5");
		adx345.addValue(0, "V", "6");
		adx345.addValue(0, "V", "7");
		adx345.addValue(0, "V", "8");
		adx345.addValue(0, "V", "9");
		adx345.addValue(0, "V", "10");
        chart=ChartFactory.createLineChart("ADXL345 DATA", "TIME", "ADX", adx345);
//        XYPlot plot = (XYPlot) chart.getPlot();
//        XYLineAndShapeRenderer xylinerenderer = (XYLineAndShapeRenderer)plot.getRenderer();
//        xylinerenderer.setBaseShapesVisible(true); 
//      //����������ʾ�����ݵ��ֵ
//        XYItemRenderer xyitem = plot.getRenderer(); 
//        xyitem.setBaseItemLabelsVisible(true);
//        xyitem.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.BASELINE_CENTER)); 
//        xyitem.setBaseItemLabelGenerator(new StandardXYItemLabelGenerator());
//        xyitem.setBaseItemLabelFont(new Font("Dialog", 1, 12)); 
//        plot.setRenderer(xyitem);
        //���Բ�����API�ĵ�,��һ�������Ǳ��⣬�ڶ���������һ�����ݼ���������������ʾ�Ƿ���ʾLegend�����ĸ�������ʾ�Ƿ���ʾ��ʾ�������������ʾͼ���Ƿ����URL
        paneladxl = new ChartPanel(chart);
		
		paneladx.setLayout(new BoxLayout(paneladx, BoxLayout.Y_AXIS));
		paneladxl = new ChartPanel(chart);
		//paneladxl.setLayout(new BoxLayout(paneladx, BoxLayout.Y_AXIS));
		paneladx.add(paneladxl);
		paneladx.add(flash);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(BorderLayout.CENTER, paneladxl);
		frame.getContentPane().add(BorderLayout.SOUTH, paneladx);
		frame.getContentPane().add(BorderLayout.EAST, paneltext);
		frame.getContentPane().add(BorderLayout.WEST, panellabel);
		frame.setSize(900, 900);
		frame.setVisible(true);
	}
	public void adxqueue() {
//		for(Integer x:AdxlX)
//		{
//			textArea.append(String.valueOf(x)+"\n");
//		}
		int ix =1;
		for(Integer x:AdxlX)
		{
			adx345.addValue(x, "X", String.valueOf(ix));
			ix++;
			//textArea.append(String.valueOf(ix)+"\n");
			if(ix==11)
			{
				break;
			}
		}
		int iY =1;
		for(Integer x:AdxlY)
		{
			adx345.addValue(x, "Y", String.valueOf(iY));
			iY++;
			if(iY==11)
			{
				break;
			}
		}
		int iZ =1;
		for(@SuppressWarnings("unused") Integer x:AdxlZ)
		{
			adx345.addValue(x, "Z", String.valueOf(iZ));
			iZ++;
			if(iZ==11)
			{
				break;
			}
		}
		int iV =1;
		for(@SuppressWarnings("unused") Integer x:AdxlV)
		{
			adx345.addValue(x, "V", String.valueOf(iV));
			iV++;
			if(iV==11)
			{
				break;
			}
		}
		paneladx.repaint();
	}
	class Flash implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			adxqueue();
		}
		
	}
	class SeverRun implements Runnable{

		@Override
		public void run() {
			// TODO Auto-generated method stub
			String message;
			try {
				
//				byte[] buf = new byte[16];
//				int len = stream.read(buf);
//				String text = new String(buf,0,len);
//				textArea.append(ip+" :"+text+"\n");
				//streamReader.toString()
				while((message =reader.readLine())!=null)
				{
					textArea.append("run recv :"+message+"\n");
					//�����ַ���
					String temp[] = message.split(":");
					String t1 = temp[0].toString();
					//textArea.append("t1  :"+t1+"\n");
					if(t1.equals("HCSR"))//������
					{
						String t2 = temp[1].toString();
						ultrasonic_num.repaint();
						ultrasonic_num.setText(t2);
					}
					else if(t1.equals("FIRE"))//����
					{
						String t2 = temp[1].toString();
						flame_state.repaint();
						flame_state.setText("fire warning!");
					}
					else if(t1.equals("LIGH"))//����
					{
						String t2 = temp[1].toString();
						photosensitive_state.repaint();
						photosensitive_state.setText("light!");
						photosensitive_state.setBackground(Color.LIGHT_GRAY);
						//�������ڣ���ʱ��д��
					}
					else if(t1.equals("THER"))//�Ⱥ���
					{
						String t2 = temp[1].toString();
						thermalinfrared_state.repaint();
						thermalinfrared_state.setText("human coming!");
						thermalinfrared_state.setBackground(Color.YELLOW);
					}
					else if(t1.equals("MAX"))//����Ѫ��
					{
						String t2 = temp[1].toString();
						String t3 = temp[2].toString();
						heartrate_num.repaint();
						heartrate_num.setText(t2);
						oxygen_num.repaint();
						oxygen_num.setText(t3);
					}
					else if(t1.equals("DHT"))//��ʪ��
					{
						String t2 = temp[1].toString();
						String t3 = temp[2].toString();
						temperature_num.repaint();
						temperature_num.setText(t2);
						humidity_num.repaint();
						humidity_num.setText(t3);
					}
					if(t1.equals("ADX"))//��������ͼ
					{
						textArea.append("�յ�ADX\n");
						String t2 = temp[1].toString();//x
						String t3 = temp[2].toString();//y
						String t4 = temp[3].toString();//z
						String t5 = temp[4].toString();//v
						AdxlX.poll();
						AdxlX.add(Integer.parseInt(t2));
						
						AdxlY.poll();
						AdxlY.add(Integer.parseInt(t3));
						
						AdxlZ.poll();
						AdxlZ.add(Integer.parseInt(t4));
						
						AdxlV.poll();
						AdxlV.add(Integer.parseInt(t5));
						
						adxqueue();
						
					}
				}

		} catch (Exception e2) {
			// TODO: handle exception
			System.out.println("�����쳣.\n");
		}
		}
		
	}
	class SeverOpen implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			textArea.append("server socket open  ing!\n");
			try {
				//@SuppressWarnings("resource")
				serverSocket = new ServerSocket(6699);
				
					Socket socket = serverSocket.accept(); 
					
//					ip = socket.getInetAddress().getHostAddress();
//					stream = socket.getInputStream();
				
					streamReader = new InputStreamReader(socket.getInputStream());
					reader = new BufferedReader(streamReader);	
					//reader.read(new CharBuffer);
					
					writer = new PrintWriter(socket.getOutputStream());
					
					Thread tserver = new Thread(new SeverRun());
					tserver.start(); 
					textArea.append("��������������\n");
				
			} catch (Exception e2) {
				// TODO: handle exception
				System.out.println("�����쳣.\n");
			}
		}
		
	}
	class SeverClose implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				serverSocket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}

}
