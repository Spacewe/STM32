/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "adxl345.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
uint8_t Tim_num;//���ڶ�ʱ������
uint8_t adx_state ;
/*
��ʼ��90
�������壺91
ʧ�غ�ײ����92
ײ����ֹ��93
��ʱ���޶�����94
��ʱ���������壺95
*/
uint8_t waitforstable;//�ȴ�3.5s�����Ϊ��ʼ״̬������ײ������Ҫ���뾲ֹ״̬
uint8_t wautforstrike;//�ȴ�200ms�����ʼ״̬������ʧ�غ�200ms��Ҫ����ײ��״̬
uint8_t freefall;
int16_t InitialStatus[3];//��ʼ״̬
int16_t Acceleration[3];
int16_t DeltaAcceleration[3];
int16_t DeltaVectorSum;
/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
	MX_GPIO_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_I2C2_Init();

  /* USER CODE BEGIN 2 */
	printf("��ʼ��ʼ��\n");
	AdX345_Init();
	  
	adx_state =90;//״̬��ʼ��
	
	InitialStatus[0]=0x1000; // X axis=0g, unsigned short int, 13 bit resolution, 0x1000 = 4096 = 0g,+/-0xFF = +/-256 = +/-1g
	InitialStatus[1]=0x0F00; // Y axis=-1g
	InitialStatus[2]=0x1000; // Z axis=0g
	printf("��ʼ�����\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(GPIO_Pin);
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_GPIO_EXTI_Callback could be implemented in the user file
   */
	 if(GPIO_Pin==GPIO_PIN_8)
	 {
		 //printf("����INT0�ж�\n");
			HAL_NVIC_DisableIRQ(EXTI9_5_IRQn);//���ж�ʧ��
			//HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
			uint8_t intsource;
			intsource = ADXL_getInterruptSource();
			//printf("����ж�Դ\n");
			if((intsource & XL345_ACTIVITY)==XL345_ACTIVITY)
			{
				//printf("�ж�Դ��ACT\n");
				if(adx_state==91)
				{
					adx_state =92;
					printf("ʧ�غ�ײ������\n");
					//printf("STATE:91->92\n");
					ADXL_setActivityThreshold(0x08);
					ADXL_setInactivityThreshold(0x03);
					ADXL_setTimeInactivity(0x02);
					ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
                | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |
                XL345_ACT_AC);
							HAL_TIM_Base_Start_IT(&htim3);//��ʼ��ʱ���жϣ���ʼ��ʱ���������3.5�룬�ٱ�Ϊ��ʼ��
							waitforstable=0;
				}
				else if(adx_state==94)
				{
					adx_state =90;
					printf("������վ������\n");
					//printf("STATE:94->90\n");
					ADXL_setActivityThreshold(0x20);
					ADXL_setInactivityThreshold(0x03);
					ADXL_setTimeInactivity(0x02);
					ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
                | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |
                XL345_ACT_DC);
				}
			}
			else if((intsource & XL345_INACTIVITY)==XL345_INACTIVITY)
			{
				//printf("�ж�Դ��INACT\n");
				if(adx_state==92)
				{
					adx_state=93;
					printf("ײ�������ֹ\n");
					HAL_TIM_Base_Stop_IT(&htim3);//�ر��ж�,���ټ���3.5��
					//printf("STATE:92->93\n");
					DeltaVectorSum=0;
					int i;
					for(i=0;i<3;i++)
					{
						if(i==0)
						{
							Acceleration[i] = ADXL_getAx();
						}
						else if(i==1)
						{
							Acceleration[i] = ADXL_getAy();
						}
						else if(i==2)
						{
							Acceleration[i] = ADXL_getAz();
						}
						if(Acceleration[i] <0x1000)
						{
							Acceleration[i]=Acceleration[i]+0x1000;
						}
						else
						{
							Acceleration[i]=Acceleration[i]-0x1000;
						}
						if(Acceleration[i]>InitialStatus[i])
						{
							DeltaAcceleration[i] = Acceleration[i]-InitialStatus[i];
						}
						else
						{
							DeltaAcceleration[i] = InitialStatus[i]-Acceleration[i];
						}
						DeltaVectorSum = DeltaVectorSum+ DeltaAcceleration[i]*DeltaAcceleration[i];
						if(DeltaVectorSum>0x7D70)//1g=0xFF, 0x7D70=0.7g^2
						{
								
								adx_state=94;
								//printf("STATE:93->94\n");
								printf("��⵽һ�ε���\n");
								ADXL_setActivityThreshold(0x08);
								ADXL_setInactivityThreshold(0x03);
								ADXL_setTimeInactivity(0x0A);//#define NOMOVEMENT_TIME 0x0A //1s/LSB, 0x0A=10s
								ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE |
									XL345_INACT_Y_ENABLE | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE |XL345_ACT_X_ENABLE | XL345_ACT_AC);
						}
						else
						{
							adx_state=90;
							//printf("STATE:93->90\n");
							ADXL_setActivityThreshold(0x20);
							ADXL_setInactivityThreshold(0x03);
							ADXL_setTimeInactivity(0x02);
							ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE |
								XL345_INACT_Y_ENABLE | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE |
								XL345_ACT_X_ENABLE | XL345_ACT_DC);
						
						}
					}
					//�ͳ�ʼ״̬�Ƚ�
					//������������94
					//û�������90
					
				}
				else if(adx_state==94)
				{
					adx_state=95;
					printf("��ʱ����������\n");
					//printf("STATE:94->95\n");
					ADXL_setActivityThreshold(0x20);
					ADXL_setInactivityThreshold(0x03);
					ADXL_setTimeInactivity(0x02);
					ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
                                                      | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |
                                                      XL345_ACT_DC);
					adx_state=90;
				}
				
			}
			else if((intsource & XL345_FREEFALL)==XL345_FREEFALL)
			{
				//printf("�ж�Դ��FF\n");
				if(adx_state==90)
				{
					adx_state=91;
					//printf("STATE:90->91\n");
					printf("ʧ��\n");
					ADXL_setActivityThreshold(0x20);
					ADXL_setInactivityThreshold(0x03);
					ADXL_setTimeInactivity(0x02);
					ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
                                                      | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |
                                                      XL345_ACT_DC);
					HAL_TIM_Base_Start_IT(&htim3);//�����жϣ��������200ms���򷵻س�ʼ״̬
					wautforstrike=0;
					freefall=0;
				}
				else if(adx_state==91)
				{
					if(wautforstrike<5)
					{
						freefall= freefall+wautforstrike;
					}
					else
					{
						freefall=0;
					}
					wautforstrike=0;
					if(freefall>=15)
					{
						adx_state=95;
						//printf("STATE:91->95\n");
						printf("��ʱ�����\n");
						ADXL_setActivityThreshold(0x20);
						ADXL_setInactivityThreshold(0x03);
						ADXL_setTimeInactivity(0x02);
						ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
                    | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |
                    XL345_ACT_DC);
						adx_state=90;
						printf("STATE:91->90\n");
					}
			
				}
				else
				{
					freefall=0;
				}
			}
			HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);//����ٿ����ж�
			//printf("�˳�INT0�ж�\n");
	 }
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(htim);
  /* NOTE : This function Should not be modified, when the callback is needed,
            the __HAL_TIM_PeriodElapsedCallback could be implemented in the user file
   */
	  if(htim->Instance == htim3.Instance)
		{
			//Tim_num++;
			if(adx_state == 92)
			{
				waitforstable++;
				if(waitforstable>=175)
				{
					HAL_TIM_Base_Stop_IT(&htim3);//�ر��ж�
					adx_state =90;//��Ϊ��ʼ��
					printf("��ʱ���жϣ�92->90,�Ѿ�����3.5s\n");
					ADXL_setActivityThreshold(0x20);
					ADXL_setInactivityThreshold(0x03);
					ADXL_setTimeInactivity(0x02);
					ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
                | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |
                XL345_ACT_DC);
								
				}
			}
			else if(adx_state == 91)
			{
				wautforstrike++;
				if(wautforstrike>=10)
				{
					HAL_TIM_Base_Stop_IT(&htim3);//�ر��ж�
					adx_state =90;//��Ϊ��ʼ��
					printf("��ʱ���жϣ�91->90,�Ѿ�����200ms\n");
					ADXL_setActivityThreshold(0x20);
					ADXL_setInactivityThreshold(0x03);
					ADXL_setTimeInactivity(0x02);
					ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE | XL345_INACT_Y_ENABLE
          | XL345_INACT_X_ENABLE | XL345_INACT_AC | XL345_ACT_Z_ENABLE | XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE |XL345_ACT_DC);
				}
			}
		}

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
