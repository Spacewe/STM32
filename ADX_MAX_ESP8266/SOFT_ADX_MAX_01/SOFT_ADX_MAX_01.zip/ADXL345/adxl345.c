/**
 * Includes
 */

#include "stm32f1xx_hal.h"
#include "adxl345.h"


int16_t GetMedianNum(int16_t * bArray, int16_t iFilterLen)
{
    uint16_t i,j;// ????
    int32_t bTemp;

    // ???????????
    for (j = 0; j < iFilterLen - 1; j ++)
    {
        for (i = 0; i < iFilterLen - j - 1; i ++)
        {
            if (bArray[i] > bArray[i + 1])
            {
                // ??
                bTemp = bArray[i];
                bArray[i] = bArray[i + 1];
                bArray[i + 1] = bTemp;
            }
        }
    }

    // ????
    if ((iFilterLen & 1) > 0)
    {
        // ????????,????????
        bTemp = bArray[(iFilterLen + 1) / 2];
    }
    else
    {
        // ????????,???????????
        bTemp = (bArray[iFilterLen / 2] + bArray[iFilterLen / 2 + 1]) / 2;
    }

    return (int16_t)bTemp;
}
void AdX345_Init()
{
	printf("ID: %d\n",ADXL_getDevId());
	ADXL_setOffset(ADXL345_X,0xFF);
	ADXL_setOffset(ADXL345_Y,0x05);
	ADXL_setOffset(ADXL345_Z,0xFF);
	
	ADXL_setActivityThreshold(0x20);
	ADXL_setInactivityThreshold(0x03);
	ADXL_setTimeInactivity(0x02);
	ADXL_setActivityInactivityControl(XL345_INACT_Z_ENABLE|XL345_INACT_Y_ENABLE | XL345_INACT_X_ENABLE
	| XL345_INACT_AC | XL345_ACT_Z_ENABLE|XL345_ACT_Y_ENABLE | XL345_ACT_X_ENABLE | XL345_ACT_DC);
	ADXL_setFreefallThreshold(0x0C);
	ADXL_setFreefallTime(0x06);
	
		ADXL_setPowerControl(0x00);
		//3.2kHz data rate.
		ADXL_setDataRate(ADXL345_100HZ);
	ADXL_setInterruptEnableControl(XL345_ACTIVITY | XL345_INACTIVITY | XL345_FREEFALL);
	ADXL_setInterruptMappingControl(0X00);
	
		//Full resolution, +/-16g, 4mg/LSB.
		ADXL_setDataFormatControl(0x0B);
		//ADXL345Registers[XL345_DATA_FORMAT]=XL345_FULL_RESOLUTION | XL345_DATA_JUST_RIGHT | XL345_RANGE_16G;
		
		//Measurement mode.
		ADXL_setPowerControl(0x08);

}
uint8_t ADXL_getDevId(void) {

    return ADXL_readOneByte(ADXL345_DEVID_REG);
}

uint8_t ADXL_getTapThreshold(void) {

    return ADXL_readOneByte(ADXL345_THRESH_TAP_REG);

}

void ADXL_setTapThreshold(uint8_t threshold) {

    ADXL_writeOneByte(ADXL345_THRESH_TAP_REG, threshold);
}

uint8_t ADXL_getOffset(uint8_t axis) {

    uint8_t address = 0;

    if (axis == ADXL345_X) {
        address = ADXL345_OFSX_REG;
    } else if (axis == ADXL345_Y) {
        address = ADXL345_OFSY_REG;
    } else if (axis == ADXL345_Z) {
        address = ADXL345_OFSZ_REG;
    }

    return ADXL_readOneByte(address);

}

void ADXL_setOffset(uint8_t axis, uint8_t offset) {

    uint8_t address = 0;

    if (axis == ADXL345_X) {
        address = ADXL345_OFSX_REG;
    } else if (axis == ADXL345_Y) {
        address = ADXL345_OFSY_REG;
    } else if (axis == ADXL345_Z) {
        address = ADXL345_OFSZ_REG;
    }

    ADXL_writeOneByte(address, offset);

}

uint16_t ADXL_getTapDuration(void) {

    return ADXL_readOneByte(ADXL345_DUR_REG)*625;

}

void ADXL_setTapDuration(uint16_t duration_us) {

    uint8_t tapDuration = duration_us / 625;

    ADXL_writeOneByte(ADXL345_DUR_REG, tapDuration);

}

float ADXL_getTapLatency(void) {

    return ADXL_readOneByte(ADXL345_LATENT_REG)*1.25;

}

void ADXL_setTapLatency(uint16_t latency_ms) {

    uint8_t tapLatency = latency_ms / 1.25;

    ADXL_writeOneByte(ADXL345_LATENT_REG, tapLatency);

}

float ADXL_getWindowTime(void) {

    return ADXL_readOneByte(ADXL345_WINDOW_REG)*1.25;

}

void ADXL_setWindowTime(uint16_t window_ms) {

    uint8_t windowTime = window_ms / 1.25;

    ADXL_writeOneByte(ADXL345_WINDOW_REG, windowTime);

}

uint8_t ADXL_getActivityThreshold(void) {

    return ADXL_readOneByte(ADXL345_THRESH_ACT_REG);

}

void ADXL_setActivityThreshold(uint8_t threshold) {

    ADXL_writeOneByte(ADXL345_THRESH_ACT_REG, threshold);

}

uint8_t ADXL_getInactivityThreshold(void) {

    return ADXL_readOneByte(ADXL345_THRESH_INACT_REG);

}

void ADXL_setInactivityThreshold(uint8_t threshold) {

    ADXL_writeOneByte(ADXL345_THRESH_INACT_REG, threshold);

}

uint8_t ADXL_getTimeInactivity(void) {

    return ADXL_readOneByte(ADXL345_TIME_INACT_REG);

}

void ADXL_setTimeInactivity(uint8_t timeInactivity) {

    ADXL_writeOneByte(ADXL345_TIME_INACT_REG, timeInactivity);

}

uint8_t ADXL_getActivityInactivityControl(void) {

    return ADXL_readOneByte(ADXL345_ACT_INACT_CTL_REG);

}

void ADXL_setActivityInactivityControl(uint8_t settings) {

    ADXL_writeOneByte(ADXL345_ACT_INACT_CTL_REG, settings);

}

uint8_t ADXL_getFreefallThreshold(void) {

    return ADXL_readOneByte(ADXL345_THRESH_FF_REG);

}

void ADXL_setFreefallThreshold(uint8_t threshold) {

    ADXL_writeOneByte(ADXL345_THRESH_FF_REG, threshold);

}

uint16_t ADXL_getFreefallTime(void) {

    return ADXL_readOneByte(ADXL345_TIME_FF_REG)*5;

}

void ADXL_setFreefallTime(uint16_t freefallTime_ms) {

    uint8_t freefallTime = freefallTime_ms / 5;

    ADXL_writeOneByte(ADXL345_TIME_FF_REG, freefallTime);

}

uint8_t ADXL_getTapAxisControl(void) {

    return ADXL_readOneByte(ADXL345_TAP_AXES_REG);

}

void ADXL_setTapAxisControl(uint8_t settings) {

    ADXL_writeOneByte(ADXL345_TAP_AXES_REG, settings);

}

uint8_t ADXL_getTapSource(void) {

    return ADXL_readOneByte(ADXL345_ACT_TAP_STATUS_REG);

}

void ADXL_setPowerMode(uint8_t mode) {

    //Get the current register contents, so we don't clobber the rate value.
    uint8_t registerContents = ADXL_readOneByte(ADXL345_BW_RATE_REG);

    registerContents = (mode << 4) | registerContents;

    ADXL_writeOneByte(ADXL345_BW_RATE_REG, registerContents);

}

uint8_t ADXL_getPowerControl(void) {

    return ADXL_readOneByte(ADXL345_POWER_CTL_REG);

}

void ADXL_setPowerControl(uint8_t settings) {

    ADXL_writeOneByte(ADXL345_POWER_CTL_REG, settings);

}

uint8_t ADXL_getInterruptEnableControl(void) {

    return ADXL_readOneByte(ADXL345_INT_ENABLE_REG);

}

void ADXL_setInterruptEnableControl(uint8_t settings) {

    ADXL_writeOneByte(ADXL345_INT_ENABLE_REG, settings);

}

uint8_t ADXL_getInterruptMappingControl(void) {

    return ADXL_readOneByte(ADXL345_INT_MAP_REG);

}

void ADXL_setInterruptMappingControl(uint8_t settings) {

    ADXL_writeOneByte(ADXL345_INT_MAP_REG, settings);

}

uint8_t ADXL_getInterruptSource(void){

    return ADXL_readOneByte(ADXL345_INT_SOURCE_REG);

}

uint8_t ADXL_getDataFormatControl(void){

    return ADXL_readOneByte(ADXL345_DATA_FORMAT_REG);

}

void ADXL_setDataFormatControl(uint8_t settings){

    ADXL_writeOneByte(ADXL345_DATA_FORMAT_REG, settings);

}

void ADXL_setDataRate(uint8_t rate) {

    //Get the current register contents, so we don't clobber the power bit.
    uint8_t registerContents = ADXL_readOneByte(ADXL345_BW_RATE_REG);

    registerContents &= 0x10;
    registerContents |= rate;

    ADXL_writeOneByte(ADXL345_BW_RATE_REG, registerContents);

}

int16_t ADXL_getAx(void){

    uint8_t buffer[2];
    
    ADXL_readTwoByte(ADXL345_DATAX0_REG, buffer);
    
    return (int16_t)((uint16_t)buffer[1] << 8 | buffer[0]);
}


int16_t ADXL_getAy(void){

    uint8_t buffer[2];
    
    ADXL_readTwoByte(ADXL345_DATAY0_REG, buffer);
    
    return (int16_t)((uint16_t)buffer[1] << 8 | buffer[0]);
}

int16_t ADXL_getAz(void){

    uint8_t buffer[2];
    
    ADXL_readTwoByte(ADXL345_DATAZ0_REG, buffer);
    
    return (int16_t)((uint16_t)buffer[1] << 8 | buffer[0]);
}



void ADXL_getOutput(int16_t* readings){
    
      uint8_t buffer[2];
    
    ADXL_readTwoByte(ADXL345_DATAX0_REG, buffer);
    readings[0] = (int16_t)((uint16_t)buffer[1] << 8 | buffer[0]);
    ADXL_readTwoByte(ADXL345_DATAY0_REG, buffer);
    readings[1] = (int16_t)((uint16_t)buffer[1] << 8 | buffer[0]);
    ADXL_readTwoByte(ADXL345_DATAZ0_REG, buffer);
    readings[2] = (int16_t)((uint16_t)buffer[1] << 8 | buffer[0]);

}

uint8_t ADXL_getFifoControl(void){

    return ADXL_readOneByte(ADXL345_FIFO_CTL);

}

void ADXL_setFifoControl(uint8_t settings){

    ADXL_writeOneByte(ADXL345_FIFO_STATUS, settings);

}

uint8_t ADXL_getFifoStatus(void){

    return ADXL_readOneByte(ADXL345_FIFO_STATUS);

}

uint8_t ADXL_readOneByte(uint8_t address) {
	uint8_t  rx[1];
	uint8_t tx[1];

	tx[0]=address;
	HAL_I2C_Master_Transmit(&hi2c2,ADXL345_I2C_WRITE, tx,1,10000);
	HAL_I2C_Master_Receive(&hi2c2,ADXL345_I2C_READ,rx,1,10000);

	return rx[0];
}

void ADXL_writeOneByte(uint8_t address, uint8_t data) {
	uint8_t tx[2];
 
	tx[0]=address;
	tx[1]=data;

	HAL_I2C_Master_Transmit(&hi2c2,ADXL345_I2C_WRITE,tx,2,10000);
}

void ADXL_readTwoByte(uint8_t startAddress, uint8_t* buffer) {
	//Send address to start reading from.
	uint8_t tx[1];
	tx[0]=startAddress;
	HAL_I2C_Master_Transmit(&hi2c2,ADXL345_I2C_WRITE, tx,1,10000);
	HAL_I2C_Master_Receive(&hi2c2,ADXL345_I2C_READ,(uint8_t *)buffer,2,10000);
}

void ADXL_writeTwoByte(uint8_t startAddress, uint8_t* buffer) {
	//Send address to start reading from.
	uint8_t tx[1];
	tx[0]=startAddress;
	HAL_I2C_Master_Transmit(&hi2c2,ADXL345_I2C_WRITE, tx,1,10000);
	HAL_I2C_Master_Transmit(&hi2c2,ADXL345_I2C_WRITE, (uint8_t *)buffer,2,10000);
}
